#!/bin/bash
printf "Your environment is $1"
